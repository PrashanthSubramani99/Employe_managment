<?php 
include("../model/MasterModel.php");
$class1=new Crud();
## Read value
$draw = $_POST['draw'];
$row = $_POST['start'];
$rowperpage = $_POST['length']; // Rows display per page
$columnIndex = $_POST['order'][0]['column']; // Column index
$columnName = $_POST['columns'][$columnIndex]['data']; // Column name
$columnSortOrder = $_POST['order'][0]['dir']; // asc or desc
$searchValue = $_POST['search']['value']; // Search value
$searchArray = array();
$class1=new Crud();
## Search 
$searchQuery = " ";
if($searchValue != ''){
   $searchQuery = " AND (name LIKE :name or 
        mobile LIKE :mobile OR 
        address LIKE :address ) ";
   $searchArray = array( 
        'name'=>"%$searchValue%", 
        'mobile'=>"%$searchValue%",
        'address'=>"%$searchValue%"
   );
}


$sql = $class1->get_employee_data("personal_info","carrier_info","resume");

// $result = array_unique($sql);
// $resultset = mysqli_query($conn, $sql) or die("database error:". mysqli_error($conn));
$data = array();
// while( $rows = mysqli_fetch_assoc($resultset) ) {
// 	$data[] = $rows;
// }


foreach($sql as $rows){
     $data[] = $rows;
}
// print_r($data);
// exit();


$results = array(
	"sEcho" => 1,
"iTotalRecords" => count($data),
"iTotalDisplayRecords" => count($data),
  "aaData"=>$data);
echo json_encode($results);

?>