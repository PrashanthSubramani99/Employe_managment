<?php 
include("../model/MasterModel.php");
$username= $_POST['username'];
$email = $_POST["email"];
$password =$_POST['password'];
if (isset($username)) {
    $class1=new Crud();
    $create_datetime = date("Y-m-d H:i:s");
    $result = $class1->register($username,md5($password),$email,$create_datetime);
    if ($result) {
        $data = array('data' => 'success');
    } else {
        $data = array('data' => 'error');
    }
    echo json_encode($data);
}


?>