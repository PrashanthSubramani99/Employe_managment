<?php 
include("../model/MasterModel.php");

$id=$_POST['id'];

if(isset($id)){
    $class1=new Crud();

    $result = $class1->delete_employee("personal_info",$id);
    $result = $class1->delete_employee("carrier_info",$id);
    $result = $class1->delete_employee("resume",$id);
    // ,"carrier_info","resume"
    if($result){
        $data = array('responce' => 'success');
    }else{
        $data = array('responce' => 'error');
    }
    echo json_encode($data);

}


?>