<?php 
include("../model/MasterModel.php");

$id=$_POST['id'];

if(isset($id)){
    $class1=new Crud();

    $data=$class1->edit_employee("personal_info","carrier_info","resume",$id);
    // print_r($data);
    // exit();
    if($data){
        $data = array('responce' => 'success',"data"=>$data);
    }else{
        $data = array('responce' => 'error');
    }
    echo json_encode($data);

}


?>