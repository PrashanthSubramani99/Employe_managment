<?php 
include("../model/MasterModel.php");
$email = $_POST["email"];
$password =$_POST['password'];

session_start();
if(isset($email) && isset($password)){
    $class1=new Crud();
    $result = $class1->login($email,$password);
    $rows = Count($result);
    if ($rows == 1) {
        $_SESSION['login'] = true;  
        $_SESSION['username'] = $result[0]['username'];
        $data = array('data' => 'success');
    } else {
        $data = array('data' => 'error');
    }
    echo json_encode($data);
}


?>