<?php 
include("../model/MasterModel.php");

$employee_name = $_POST['employee_name'];
$employee_id =  $_POST['employee_id'];
$mobile =  $_POST['mobile'];
$language =  $_POST['language'];
$qualification =  $_POST['qualification'];
$address =  $_POST['address'];
$create_datetime = date("Y-m-d H:i:s");
$target_dir = 'uploads/';
$profile_pic_name = $_FILES["edit_img"]["name"];
$resume_name = $_FILES["edit_res"]["name"];
$target_file = $target_dir . basename($_FILES["edit_img"]["name"]);
$resume_target_file = $target_dir . basename($_FILES["edit_res"]["name"]);
$imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
$resumeFileType = strtolower(pathinfo($resume_target_file,PATHINFO_EXTENSION));
$extensions_pic_arr = array("jpg","jpeg","png","gif");
$extensions_res_arr = array("doc","pdf");

if(isset($employee_name)){
    $class1=new Crud();
      // Check extension

  if( in_array($imageFileType,$extensions_pic_arr) ){
    // Upload file
    if(move_uploaded_file($_FILES['edit_img']['tmp_name'],$target_dir.$profile_pic_name)){
        $picture = $target_file;
    }

 }

 if( in_array($resumeFileType,$extensions_res_arr) ){
    // Upload file
    if(move_uploaded_file($_FILES['edit_res']['tmp_name'],$target_dir.$resume_name)){
        $resume = $resume_target_file;
    }

 }
        $data = array(
            'emp_id'=>$employee_id,
            'profile_pic'=>$picture,
            'name'=>$employee_name,
            'mobile'=>$mobile,
            'address'=>$address,
            'create_at'=>$create_datetime
        );
    $result = $class1->addData("personal_info",$data);

    $resume_data = array(
        'emp_id'=>$employee_id,
        'resume'=>$resume,
        'create_at'=>$create_datetime
    );

    $result = $class1->addData("resume",$resume_data);

    $carrier_data = array(
        'emp_id'=>$employee_id,
        'qualification'=>$qualification,
        'language'=> $language,
        'create_at'=>$create_datetime
    );

    $result = $class1->addData("carrier_info",$carrier_data);

    if($result){
        $data = array('responce' => 'success');
    }else{
        $data = array('responce' => 'error');
    }
    echo json_encode($data);

}


?>