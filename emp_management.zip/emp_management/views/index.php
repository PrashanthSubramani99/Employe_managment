<?php
include("../auth/sessions.php");
?>
<!DOCTYPE html>

<!-- =========================================================
* Sneat - Bootstrap 5 HTML Admin Template - Pro | v1.0.0
==============================================================

* Product Page: https://themeselection.com/products/sneat-bootstrap-html-admin-template/
* Created by: ThemeSelection
* License: You must have a valid license purchased in order to legally use the theme for your project.
* Copyright ThemeSelection (https://themeselection.com)

=========================================================
 -->
<!-- beautify ignore:start -->
<html
  lang="en"
  class="light-style layout-menu-fixed"
  dir="ltr"
  data-theme="theme-default"
  data-assets-path="../assets/"
  data-template="vertical-menu-template-free">
  <?php require('header.php')  ?>
  <body>
    <!-- Layout wrapper -->
    <div class="layout-wrapper layout-content-navbar">
      <div class="layout-container">
        <!-- Menu -->
      <?php require('sidebar.php') ?>
        <!-- / Menu -->

        <!-- Layout container -->
        <div class="layout-page">

          <?php require('navbar.php') ?>




          <!-- Content wrapper -->
          <div class="content-wrapper">
            <!-- Content -->

            <div class="container-xxl flex-grow-1 container-p-y">
            <div class="col-lg-12 mb-4 order-0">
                  <div class="card">
                    <div class="d-flex align-items-end row">
                      <div class="col-sm-12">
                        <div class="card-body">
                            <!-- Modal -->
                          <!-- Button trigger modal -->
                          <button type="button" class="btn btn-primary" id="add_form" data-bs-toggle="modal" data-bs-target="#largeModal">
                          Add Employee
                        </button>

                         <!-- Bordered Table -->
                         <div class="table-responsive text-nowrap mt-4">
                    <table class="table table-bordered display dataTable" id='empTable'>
                      <thead class='table-dark'>
                        <tr>
                          <th>Sno</th>
                          <th>Profile pic</th>
                          <th>Employee Name</th>
                          <th>Mobile</th>
                          <th>Address</th>
                          <th>Qualification</th>
                          <th>Language</th>
                          <th>Resume</th>
                          <th>Action</th>
                        </tr>
                      </thead>
                      <tbody>
                      </tbody>
                    </table>
                  </div>
              <!--/ Bordered Table -->


                                      <!-- Large Modal -->
                        <div class="modal fade" id="largeModal" tabindex="-1" aria-hidden="true">
                        <div class="modal-dialog modal-lg" role="document">
                          <div class="modal-content">
                            <div class="modal-header">
                              <h5 class="modal-title" id="exampleModalLabel3">Add Employee</h5>
                              <button
                                type="button"
                                class="btn-close close"
                                data-bs-dismiss="modal"
                                aria-label="Close"
                              ></button>
                            </div>
                            <div class="modal-body">
                            <form id="employee_details">
                            <div class="row">
                                            <div class="col-md-4">
                                                <div class="form-group">
                                                    <label for="">Employee Name <span class="text-danger">*</span> </label>
                                                    <input type="name" class="form-control" id="name" name="name" placeholder="Enter name" required>
                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="form-group">
                                                    <label for="">Employee ID <span class="text-danger">*</span> </label>
                                                    <input type="name" class="form-control" id="employee_id" name="employee_id" placeholder="Enter employee id" required>
                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="form-group">
                                                    <label for="">Mobile <span class="text-danger">*</span> </label>
                                                    <input type="name" class="form-control" id="Mobile" name="Mobile" placeholder="Mobile" required>
                                                </div>
                                            </div>
                                            <div class="col-md-4 mt-3">
                                                <div class="form-group">
                                                    <label for="">Qualification <span class="text-danger">*</span> </label>
                                                    <select name="qualification" id="qualification" class="form-control" required>
                                                        <option value="" selected disabled>Select option</option>
                                                        <option value="CSC">Computer Science</option>
                                                        <option value="ECE">Elections and Communication Engineering</option>
                                                        <option value="EEE">Electrical and Elicatonics Engineering</option>
                                                    </select>
                                                </div>
                                            </div>


                                            <div class="col-md-4 mt-3">
                                                <div class="form-group">
                                                    <label for="">Resume <span class="text-danger">*</span> Format: Docs, Pdf </label>
                                                    <input type="file" class="form-control" id="resume" name="resume" required>
                                                </div>
                                            </div>

                                            <div class="col-md-4 mt-3">
                                                <div class="form-group">
                                                    <label for="">Profile Pic <span class="text-danger">*</span> Format: Jpg, Png </label>
                                                    <input type="file" class="form-control" id="picture" name="picture" required>
                                                </div>
                                            </div>

                                            <div class="col-md-4 mt-3">
                                                <div class="form-group">
                                                    <label for="">Programming Language <span class="text-danger">*</span>(Type: Python, Java, PHP, React, C++ )</label>
                                                    <select id="multiple" class="js-example-basic-multiple-limit select form-control" style="width: 100%;" multiple="multiple" required>
                                                        <option  value="Python">PYTHON</option>
                                                        <option  value="Java">JAVA</option>
                                                        <option  value="PHP">PHP</option>
                                                        <option  value="REACT">REACT</option>
                                                        <option  value="C++">C++</option>
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="col-md-4 mt-3">
                                                <div class="form-group ">
                                                    <label for="">Address <span class="text-danger">*</span> </label>
                                                    <textarea name="address" id="address" class="form-control" cols="30" rows="5" placeholder="Enter Address" required></textarea>
                                                </div>
                                            </div>

                                            <div class="col-md-4 mt-3">
                                                  <div id="show_img"></div>
                                            </div>

                                        </div>
 
                            </div>
                            <div class="modal-footer">
                              <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">
                                Close
                              </button>
                              <button type="submit" class="btn btn-primary" id="add">Submit</button>
                              <button type="submit" class="btn btn-primary" id="update" >Update</button>
                            </div>
                            </form>
                          </div>
                        </div>
                      </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
            </div>
            <!-- / Content -->

            <?php require('dashboardfooter.php') ?>

            <div class="content-backdrop fade"></div>
          </div>



          <!-- Content wrapper -->
        </div>
        <!-- / Layout page -->
      </div>

      <!-- Overlay -->
      <div class="layout-overlay layout-menu-toggle"></div>
    </div>
    <!-- / Layout wrapper -->
  <?php require('footer.php') ?>
  

  <script>
         $(document).ready(function() {

          $("#update").css("display","none")
          $('.js-example-basic-multiple').select2();
            $('.select').select2({
                placeholder: 'Choose Programming Language',
                allowClear: true
            });

 


            $('#empTable').DataTable({
              'processing': true,
              'serverSide': true,
              'serverMethod': 'post',
              'ajax': {
                  'url':'../Controller/Show.php'
              },
              'columns': [
                { orderable:false,
                  searchable:false,
                  data: function ( rec, type, row, meta ) {
                    return meta.row + 1;
                } },
                { orderable:false,
                  searchable:false,
                  data: function ( row,type,set ) {
                  return `
                       <img src="../controller/${row.profile_pic}" width="100px"></img>
                  `;
                } },
                { data: 'name' },
                { data: 'mobile' },
                { data: 'address' },
                { data: 'qualification' },
                { data: 'language' },
                { orderable:false,
                  searchable:false,
                  data: function ( row,type,set ) {
                  return `
                       <a href="../Controller/${row.resume}" class="btn btn-info" target="blank">View</a> 
                  `;
                } },
                { orderable:false,
                  searchable:false,
                  data: function ( row,type,set ) {
                  return `
                       <button class="btn btn-success btn-sm" onclick="edit('${row.emp_id}')">edit</button>
                       <button class="btn btn-danger btn-sm" onclick="trash('${row.emp_id}')">Delete</button> 
                  `;
                } }
              ]
          });

        });

        $("#add_form").click(function(){
          $("#employee_details")[0].reset();
          $("#update").css("display","none")
          $("#add").css("display","block")
          $('#multiple').val("").change();
        })

        $("#employee_details").submit(function(e) {
            e.preventDefault();
            var employee_name = $("#name").val();
            var employee_id = $("#employee_id").val();
            var mobile = $("#Mobile").val();
            var qualification = $("#qualification").val();
            var edit_img = $("#picture")[0].files[0];
            var edit_res = $("#resume")[0].files[0];
            var language = $('#multiple').val();
            var address = $('#address').val();

            if (employee_name == "" || employee_id == "" || mobile == "" || qualification == "" || edit_img == "" || edit_res == "" || language == "" || address == "") {
                alert("All field are required");
            } else {
                var fd = new FormData();

                fd.append("employee_name", employee_name);
                fd.append("employee_id", employee_id);
                fd.append("mobile", mobile);
                fd.append("language", language);
                fd.append("qualification", qualification);
                fd.append("address", address);
                if ($("#picture")[0].files.length > 0) {
                    fd.append("edit_img", edit_img);
                }
                if ($("#resume")[0].files.length > 0) {
                    fd.append("edit_res", edit_res);
                }

                $.ajax({
                    type: "post",
                    url:"../Controller/Insert.php",
                    data: fd,
                    processData: false,
                    contentType: false,
                    dataType: "json",
                    success: function(response) {
                        if(response.responce=="success"){
                          $(".close").click();
                          toastr["success"]("Employee Created Successfully");
                          $("#employee_details")[0].reset();
                          location.reload();
                        }else{
                          toastr["error"]("Field to create Employee");
                        }
                    },
                });
            }

        });

        function edit(id){
          $.ajax({
            url:"../Controller/Edit.php",
            type:"post",
            data:{id:id},
            dataType:"json",
            success: function(response){
              if(response.responce=="success"){
                toastr["success"]("Deleted  Successfully");
                setTimeout(function() { 
                  location.reload();
                  }, 1000);  
              }else{
                toastr["error"]("Deleted  Failed");
              }
            }
          });
        }

        function trash(id){
          $.ajax({
            url:"../Controller/Delete.php",
            type:"post",
            data:{id:id},
            dataType:"json",
            success: function(response){
              if(response.responce=="success"){
                toastr["success"]("Deleted  Successfully");
                setTimeout(function() { 
                  location.reload();
                  }, 1000);  
              }else{
                toastr["error"]("Deleted  Failed");
              }
            }
          })
        }

        function edit(id){
          $("#update").css("display","block")
          $("#add").css("display","none")
          $.ajax({
            url:"../Controller/Edit.php",
            type:"post",
            data:{id:id},
            dataType:"json",
            success: function(response){
              $("#largeModal").modal("show");
              if(response.data){
                $('#address').val(response.data[0].address);
                $('#name').val(response.data[0].name);
                $('#employee_id').val(response.data[0].emp_id);
                $('#Mobile').val(response.data[0].mobile);
                $("#show_img").html(`
                      <img src="../Controller/${response.data[0].profile_pic}" width="200" height="150">
                  `);
                  $('#qualification').val(response.data[0].qualification);
                var lang = response.data[0].language;
                let arr = lang.split(',');
                console.log(arr);
                $('#multiple').val(arr).change();
                $('#resume').val(response.data[0].resume);
                $('#picture').val(response.data[0].picture);
              }
            }
          })
        }


        $("#employee_details").submit(function(e) {
            e.preventDefault();
            var employee_name = $("#name").val();
            var employee_id = $("#employee_id").val();
            var mobile = $("#Mobile").val();
            var qualification = $("#qualification").val();
            var edit_img = $("#picture")[0].files[0];
            var edit_res = $("#resume")[0].files[0];
            var language = $('#multiple').val();
            var address = $('#address').val();

            if (employee_name == "" || employee_id == "" || mobile == "" || qualification == "" || edit_img == "" || edit_res == "" || language == "" || address == "") {
                alert("All field are required");
            } else {
                var fd = new FormData();

                fd.append("employee_name", employee_name);
                fd.append("employee_id", employee_id);
                fd.append("mobile", mobile);
                fd.append("language", language);
                fd.append("qualification", qualification);
                fd.append("address", address);
                if ($("#picture")[0].files.length > 0) {
                    fd.append("edit_img", edit_img);
                }
                if ($("#resume")[0].files.length > 0) {
                    fd.append("edit_res", edit_res);
                }

                $.ajax({
                    type: "post",
                    url:"../Controller/Update.php",
                    data: fd,
                    processData: false,
                    contentType: false,
                    dataType: "json",
                    success: function(response) {
                        if(response.responce=="success"){
                          $(".close").click();
                          toastr["success"]("Employee Created Successfully");
                          $("#employee_details")[0].reset();
                          location.reload();
                        }else{
                          toastr["error"]("Field to create Employee");
                        }
                    },
                });
            }

        });
  </script> 
  </body>
</html>