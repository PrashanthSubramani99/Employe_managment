<?php
    class Crud{
        public $con;
        public function __construct()
        {
            $this->con = new mysqli("localhost", "root","","employee_management");
            return $this->con;
        }

        public function executeQuery($query){
            return $this->con->query($query);
        }
        

        public function login($email,$password) {  
           $sql = "SELECT * FROM `users` WHERE email='$email'AND password='" . md5($password) . "'";;
           $result = $this->con->query($sql);      
           $row= mysqli_fetch_all($result, MYSQLI_ASSOC);
           return $row;
        } 
        
        public function register($username,$password,$email,$create_datetime){
            $sql="INSERT into `users` (username, password, email, create_datetime)
            VALUES ('$username', '" . $password . "', '$email', '$create_datetime')";
            $query = $this->con->query($sql);
            if($query){
                return $query;
            }
        }

        public function addData($table,$fields){
            $sql="";
            $sql.="INSERT INTO ".$table;
            $sql.="(".implode(",",array_keys($fields)).")VALUES";
            $sql.="('".implode("','",array_values($fields))."')";
            // echo $sql;
            $query = $this->con->query($sql);
            if($query){
                return $query;
            }
        }


        public function get_employee_data($table1,$table2, $table3){
            $sql="select * from $table1  LEFT JOIN $table2 on $table1.emp_id =$table2.emp_id LEFT JOIN  $table3 on $table2.emp_id = $table3.emp_id  GROUP BY $table1.emp_id";
            $result = $this->con->query($sql);      
            $row= mysqli_fetch_all($result, MYSQLI_ASSOC);
            return $row;
        }

        public function delete_employee($table,$id){
            // $sql="Delete from $table1  LEFT JOIN $table2 on $table1.emp_id =$table2.emp_id LEFT JOIN  $table3 on $table2.emp_id = $table3.emp_id  GROUP BY $table1.emp_id where $table1.emp_id = $id";
            $sql="Delete from $table where emp_id = $id";
            $result = $this->con->query($sql);      
            return $result;
        }


        public function edit_employee($table1,$table2, $table3,$id){
            $sql="select * from $table1  LEFT JOIN $table2 on $table1.emp_id =$table2.emp_id LEFT JOIN  $table3 on $table2.emp_id = $table3.emp_id where $table1.emp_id=$id GROUP BY $table1.emp_id";
            $result = $this->con->query($sql);      
            $row= mysqli_fetch_all($result, MYSQLI_ASSOC);
            return $row;
        }


}

?>